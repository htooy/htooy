<?php
header("content-Type: text/html; charset=utf-8");
header("Cache-Control: no-cache, must-revalidate");
header("Pragma: no-cache");
error_reporting(E_ERROR | E_WARNING | E_PARSE);
ob_start();
$runtime= new runtime;$runtime->start();class runtime{var $StartTime = 0;var $StopTime = 0;function get_microtime(){list($usec,$sec)=explode(' ',microtime());return((float)$usec+(float)$sec);}function start(){$this->StartTime=$this->get_microtime();}function stop(){$this->StopTime=$this->get_microtime();}function spent(){return round(($this->StopTime-$this->StartTime),6);}}

//认证 KEY
$zKey = "test";
//刷新间隔 单位:毫秒 1秒=1000毫秒 
$zSec = "1000";
//404页面
$zError = "http://www.htooy.org/404.html";
//服务器列表
$zUrls = array(
"http://127.0.0.1/status.php",
"http://127.0.0.1/status.php",
"http://127.0.0.1/status.php",
"http://127.0.0.1/status.php",
);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="zh-CN">
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="keywords" content="php,sysinfo,ajax,无刷新,实时,系统信息," />
<meta name="description" content="使用json+ajax实现的系统信息无刷新实时显示,可查看磁盘,内存,负载,系统时间,mysql状态等信息" />
<meta name="generator" content="PHP-SYSINFO" />
<meta name="author" content="LadonQ" />
<meta name="copyright" content="HTOOY.ORG" />
<script type="text/javascript" src="jquery.min.js"></script>
<style type="text/css"> 
<!--
* {margin:0; padding:0; border:none;}
li {list-style:none;}
body{font-size:14px; font-family:Tahoma,verdana; line-height:22px;}
a{color:blue;text-decoration:none;}
a:hover{text-decoration:underline;}
#info em{color:#FF9D25;}
#info strong a{color:red;}
#copyright strong a{color:#000;}
h1{text-align:center; line-height:60px; border-bottom:1px solid #C9D7F1; margin-bottom:20px;}
h2{border:0px; text-align:center; line-height:40px;}
h2 a{float:right; font-weight:normal; font-size:12px;}
h3,#footer{padding:4px 5px; text-align:left; background-color:#f0f7ff; border:1px solid #C9D7F1;}
#footer{font-size:10px; font-family:Tahoma,verdana;}
#main{width:720px;margin:0px auto;}
.clearDiv{clear: both;}
.infoList ul li{background-color:#F0F7FF; border:1px solid #C9D7F1; float:left; line-height:30px; margin:0px 6px 10px; padding:6px 10px; width:325px;}
.infoList ul li:hover {background-color:#fff;}
.statusRed{color:#f00; font-weight:bold;}
.statusGreen{color:#090; font-weight:bold;}
.infoItem {margin-bottom:10px;}
.infoItemDiv{padding:5px; margin-left:15px;}
#ServerSpace,#ServerLoadAvg,#ServerMemory,#ServerSwap,#ServerTime,#ServerMysql,#ServerNetWorks{display:none;}
-->
</style>
<?php
//VerChk
$zVersion = "0.4";
$zVers = @file_get_contents("http://htooy.googlecode.com/svn/trunk/ver/ajaxsysinfo/verchk.txt");
if (empty($zVers))$zVers = @file_get_contents("http://ver.htooy.org/ajaxsysinfo/verchk.txt");
if (empty($zVers))$zVers = null;
if (empty($zVers)){$zNewVer = "<br />";
}else{$zVer = explode("|",$zVers);
	if ($zVer[0]<=$zVersion){$zNewVer = "<br />";
	}else{$zNewVer = " | <strong><a href=\"$zVer[1]\" rel=\"external\">The latest version $zVer[0]</a></strong><br />";}
	if (empty($zVer[2])){$zMsg = null;}else{$zMsg = "<span id=\"msg\">".$zVer[2]."</span><br />";}
}
//Auth
$zNum = $_GET['num'];
$zCurls = count($zUrls);
if (($zNum!==null)&&($zNum>="0")&&($zNum<$zCurls))
{
	$zUrl = $zUrls[$zNum]."?ip=".$_SERVER["REMOTE_ADDR"];
	$zKey = md5($zKey);
	$zKey = md5(getenv("SERVER_PROTOCOL")."+".$_SERVER["REMOTE_ADDR"]."+".$_SERVER["SERVER_PORT"]."+".getenv("REQUEST_METHOD")."+".$zKey);
	$zVN = @file_get_contents($zUrl."&key=key");
	if ($zKey !== $zVN)
	{
		header("HTTP/1.1 404 Not Found");
		header("Location: $zError");
		exit;
	}
	$zNetNum = @file_get_contents($zUrl."&net=num");
	if (empty($zNetNum)&&($zNetNum<="0"))$zNetNum = 0;
	$zUrl = $zUrl."&num=".$zNum."&act=".$zKey;
}else{?>
<title>服务器列表</title>
</head>
<body>
<div id="main">
	<h1>请选择要查看的服务器</h1>
	<div id="ServerList" class="infoList">
		<ul>
<?php
for ($n=0;$n<$zCurls;$n++)
{
	$zCode = get_http_response_code($zUrls[$n]);
	if ($zCode !== "200")
	{
		echo '<li><b>服务器 [',$n+1,']</b><br />服务器状态 : <span class="statusRed">超时-',$zCode;
	}else{
		echo '<li><a href="?num=',$n,'"><b>服务器 [',$n+1,']</b></a><br />服务器状态 : <span class="statusGreen">正常-',$zCode;
	}
    echo '</span></li>';
}
?>
    	</ul>
    	<div class="clearDiv"></div>
	</div>
	<div id="footer">
		<span id="info">
			<?php
				echo $zMsg,'CopyLeft ',date("Y",time()),' , Powered by <strong>PHP-SYSINFO</strong> <em>v',$zVersion,'</em> .',$zNewVer;
				$runtime->stop();
				echo 'Processed in ',$runtime->spent(),' second(s). Memory Usage ',zFS(memory_get_usage()),'.';
			?>
		</span><br />
		<span id="copyright">
			&copy; CopyRight 2004, <strong><a href="http://www.htooy.org/" rel="external">HTOOY.ORG</a></strong> Inc.All Rights Reserved. | 
			<strong><a href="http://validator.w3.org/check?uri=referer" rel="external">Valid XHTML 1.0 Strict</a></strong> | 
			<strong><a href="http://jigsaw.w3.org/css-validator/check/referer" rel="external">Valid CSS</a></strong>
		</span>
	</div>
	<div class="clearDiv"></div>
</div>
</body>
</html>
<?php exit;}?>
<title>服务器状态</title>
</head>
<body>
<div id="main">
	<h2><a href="monitor.php">返回服务器列表</a>服务器[<span id="num">[n/a]</span>]-[<span id="IP">[n/a]</span>] 的状态</h2>
	<!-- Server Info here --> 
	<div id="ServerInfo" class="infoItem">
		<h3>服务器信息</h3>
		<div id="ServerSpace" class="infoItemDiv">
			<b>硬盘空间详情</b><br />
			剩余空间 : <span id="FreeSpace">[n/a]</span><br />
			总计空间 : <span id="TotalSpace">[n/a]</span><br />
			空间使用率 : <span id="RateSpace">[n/a]</span>
		</div>
		<div id="ServerLoadAvg" class="infoItemDiv">
			<b>服务器负载详情</b><br />
			一分钟负载 : <span id="OneLoad">[n/a]</span><br />
			五分钟负载 : <span id="FiveLoad">[n/a]</span><br />
			十五分钟负载 : <span id="FifteenLoad">[n/a]</span><br />
			进程 : <span id="ProcLoad">[n/a]</span>
		</div>
		<div id="ServerMemory" class="infoItemDiv">
			<b>物理内存详情</b><br />
			总计物理内存 : <span id="TotalMemory">[n/a]</span><br />
			已用物理内存 : <span id="UsedMemory">[n/a]</span><br />
			缓冲区使用 : <span id="CachedMemory">[n/a]</span><br />
			空闲物理内存 : <span id="FreeMemory">[n/a]</span><br />
			物理内存使用率 : <span id="RateMemory">[n/a]</span>
		</div>
		<div id="ServerSwap" class="infoItemDiv">
			<b>Swap内存详情</b><br />
			总计Swap内存 : <span id="TotalSwap">[n/a]</span><br />
			已用Swap内存 : <span id="UsedSwap">[n/a]</span><br />
			空闲Swap内存 : <span id="FreeSwap">[n/a]</span><br />
			Swap内存使用率 : <span id="RateSwap">[n/a]</span>
		</div>
		<div id="ServerTime" class="infoItemDiv">
			<b>时间</b><br />
			运行时间 : <span id="UpTime">[n/a]</span><br />
			空闲时间 : <span id="FreeTime">[n/a]</span><br />
			服务器时间 : <span id="SysTime">[n/a]</span><br />
			北京时间 : <span id="BJTime">[n/a]</span>
		</div>
		<div id="ServerMysql" class="infoItemDiv">
			<b>MySQL状态</b><br />
			MySQL : <span id="Mysql">[n/a]</span>
		</div>
<?php
if ($zNetNum>0)
{
	echo "\t\t";echo '<div id="ServerNetWorks" class="infoItemDiv">';
	echo "\n\t\t\t";echo '<b>NetWork状态</b><br />';
	echo "\n\t\t\t";echo '共有 [<span id="NetWorkNum">[n/a]</span>] 个网卡设备';
	for ($x=0;$x<$zNetNum;$x++)
	{
		echo "\n\t\t\t";
		echo '<br /><span id="NetWorkName',$x,'">[n/a]</span> : 接收 : <span id="NetWorkInput',$x,'">[n/a]</span> 发送 : <span id="NetWorkOut',$x,'">[n/a]</span>';
	}
	echo "\n\t\t";echo '</div>';echo "\n";
}
?>
		<div class="clearDiv"></div>
	</div>
	<div id="footer">
		<span id="info">
			<?php
				echo $zMsg,'CopyLeft ',date("Y",time()),' , Powered by <strong>PHP-SYSINFO</strong> <em>v',$zVersion,'</em> .',$zNewVer;
				$runtime->stop();
				echo 'Processed in ',$runtime->spent(),' second(s). Memory Usage ',zFS(memory_get_usage()),'.';
			?>
		</span><br />
		<span id="copyright">
			&copy; CopyRight 2004, <strong><a href="http://www.htooy.org/" rel="external">HTOOY.ORG</a></strong> Inc.All Rights Reserved. | 
			<strong><a href="http://validator.w3.org/check?uri=referer" rel="external">Valid XHTML 1.0 Strict</a></strong> | 
			<strong><a href="http://jigsaw.w3.org/css-validator/check/referer" rel="external">Valid CSS</a></strong>
		</span>
	</div>
	<div class="clearDiv"></div>
</div>
<script type="text/javascript"> 
<!--
$(document).ready(function(){getJSONData();});
function getJSONData()
{
	setTimeout("getJSONData()", <?php echo $zSec;?>);
	$.getJSON('<?php echo $zUrl;?>&callback=?', displayData);
}
function displayData(dataJSON)
{
	$("#key").html(dataJSON.key);
	$("#IP").html(dataJSON.ServerIP);
	$("#num").html(dataJSON.num);
	//ServerloadAvg
	if(dataJSON.ServerloadAvg[4] == "1") $("#ServerLoadAvg").show();
	if(dataJSON.ServerloadAvg[4] == "0") $("#ServerLoadAvg").hide();
	$("#OneLoad").html(dataJSON.ServerloadAvg[0]);
	$("#FiveLoad").html(dataJSON.ServerloadAvg[1]);
	$("#FifteenLoad").html(dataJSON.ServerloadAvg[2]);
	$("#ProcLoad").html(dataJSON.ServerloadAvg[3]);
	//ServerSpace
	if(dataJSON.ServerSpace.Space == "1") $("#ServerSpace").show();
	if(dataJSON.ServerSpace.Space == "0") $("#ServerSpace").hide();
	$("#FreeSpace").html(dataJSON.ServerSpace.FreeSpace);
	$("#TotalSpace").html(dataJSON.ServerSpace.TotalSpace);
	$("#RateSpace").html(dataJSON.ServerSpace.RateSpace + " %");
	//ServerMemory
	if(dataJSON.ServerMemory.Mem == "1") $("#ServerMemory").show();
	if(dataJSON.ServerMemory.Mem == "0") $("#ServerMemory").hide();
	$("#TotalMemory").html(dataJSON.ServerMemory.TotalMemory);
	$("#FreeMemory").html(dataJSON.ServerMemory.FreeMemory);
	$("#UsedMemory").html(dataJSON.ServerMemory.UsedMemory);
	$("#CachedMemory").html(dataJSON.ServerMemory.CachedMemory);
	$("#RateMemory").html(dataJSON.ServerMemory.RateMemory + " %");
	//ServerSwap
	if(dataJSON.ServerSwap.Swap == "1") $("#ServerSwap").show();
	if(dataJSON.ServerSwap.Swap == "0") $("#ServerSwap").hide();
	$("#TotalSwap").html(dataJSON.ServerSwap.TotalSwap);
	$("#FreeSwap").html(dataJSON.ServerSwap.FreeSwap);
	$("#UsedSwap").html(dataJSON.ServerSwap.UsedSwap);
	$("#RateSwap").html(dataJSON.ServerSwap.RateSwap + " %");
	//ServerTime
	if(dataJSON.ServerTime.UpTime !== "") $("#ServerTime").show();
	if(dataJSON.ServerTime.UpTime === "") $("#ServerTime").hide();
	$("#UpTime").html(dataJSON.ServerTime.UpTime);
	$("#FreeTime").html(dataJSON.ServerTime.FreeTime);
	$("#BJTime").html(dataJSON.ServerTime.BJTime);
	$("#SysTime").html(dataJSON.ServerTime.SysTime);
	//ServerMysql
	if(dataJSON.ServerMysql.SQL == "1") $("#ServerMysql").show();
	if(dataJSON.ServerMysql.SQL == "0") $("#ServerMysql").hide();
	$("#Mysql").html(dataJSON.ServerMysql.SQL);
	$("#Mysql").html(dataJSON.ServerMysql.SQLStatus);
<?php
if ($zNetNum>0)
{
	echo "\t";
	echo '//ServerNetWorks';
	echo "\n\t";
	echo 'if(dataJSON.ServerNetWorks.NetWork !== "") $("#ServerNetWorks").show();';echo "\n\t";
	echo 'if(dataJSON.ServerNetWorks.NetWork === "") $("#ServerNetWorks").hide();';echo "\n\t";
	echo '$("#NetWork").html(dataJSON.ServerNetWorks.NetWork);';echo "\n\t";
	echo '$("#NetWorkNum").html(dataJSON.ServerNetWorks.NetWorkNum);';echo "\n";
	for ($y=0;$y<$zNetNum;$y++)
	{
		echo "\t";echo '$("#NetWorkName',$y,'").html(dataJSON.ServerNetWorks.NetName',$y,');';echo "\n\t";
		echo '$("#NetWorkInput',$y,'").html(dataJSON.ServerNetWorks.NetInput',$y,');';echo "\n\t";
		echo '$("#NetWorkOut',$y,'").html(dataJSON.ServerNetWorks.NetOut',$y,');';echo "\n";
	}
}
?>
}
-->
</script>
</body>
</html>
<?php
function zFS($fileSize)
{
	$unit = array(' Bytes', ' KB', ' MB', ' GB', ' TB', ' PB', ' EB', ' ZB', ' YB');
	$i = 0;
	//由于计算机做乘法比做除法快
	$inv = 1 / 1024;
	while($fileSize >= 1024 && $i < 8)
	{
		$fileSize *= $inv;
		++$i;
	}
	$fileSizeTmp = sprintf("%.2f", $fileSize);
	//以下代码在99.99%的情况下结果会是正确的，除非你使用了"超超大数"。：）
	return ($fileSizeTmp - (int)$fileSizeTmp ? $fileSizeTmp : $fileSize) . $unit[$i];
}
function get_http_response_code($theURL)
{
	$headers = get_headers($theURL);
	return substr($headers[0], 9, 3);
}
?>