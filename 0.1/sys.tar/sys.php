<?php
header("content-Type: text/html; charset=utf-8");
header("Cache-Control: no-cache, must-revalidate");
header("Pragma: no-cache");
error_reporting(E_ERROR | E_WARNING | E_PARSE);
ob_start();
$sysInfo = sys_linux();
$nets = net_dev();
$title = "Real-time System Information";
$stime = date("Y-n-j H:i:s");
$bjtime = gmdate("Y-n-j H:i:s",time()+8*3600);
$uptime = $sysInfo['uptime'];
$freetime = $sysInfo['freetime'];
$df = round(getRealSizes(@disk_free_space(".")),4)." GB";
$mt = $sysInfo['memTotal'];
$mu = $sysInfo['memUsed'];
$mf = $sysInfo['memFree'];
$mc = $sysInfo['memCached'];
$st = $sysInfo['swapTotal'];
$su = $sysInfo['swapUsed'];
$sf = $sysInfo['swapFree'];
$load = $sysInfo['loadAvg'];

if ($_GET['act'] == "rt")
{
	$arr=array('title'=>"$title",'freeSpace'=>"$df",'TotalMemory'=>"$mt",'UsedMemory'=>"$mu",'FreeMemory'=>"$mf",'CachedMemory'=>"$mc",'TotalSwap'=>"$st",'UsedSwap'=>"$su",'FreeSwap'=>"$sf",'loadAvg'=>"$load",'uptime'=>"$uptime",'freetime'=>"$freetime",'bjtime'=>"$bjtime",'stime'=>"$stime");
	$jarr=json_encode($arr); 
	echo $_GET['callback'],'(',$jarr,')';
	exit;
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>SysInfo</title>
<script language="JavaScript" type="text/javascript" src="jquery.min.js"></script>
</head>
<body>
<div id="server" class="infoItemDiv">
Title : <span id="title">0</span><br /><br />
运行时间 : <span id="uptime">0</span><br />
空闲时间 : <span id="freetime">0</span><br />
Load Average : <span id="loadAvg">0</span><br />
硬盘可用 : <span id="freeSpace">0</span><br />
Mem共有 : <span id="TotalMemory">0</span><br />
Mem已用 : <span id="UsedMemory">0</span><br />
Mem空闲 : <span id="FreeMemory">0</span><br />
Cached化内存 : <span id="CachedMemory">0</span><br />
Swap共有 : <span id="TotalSwap">0</span><br />
Swap已用 : <span id="UsedSwap">0</span><br />
Swap空闲 : <span id="FreeSwap">0</span><br />
服务器时间 : <span id="stime">0</span><br />
北京时间 : <span id="bjtime">0</span><br />
</div><br /><hr /><br />
<?php
echo '<pre>';
//网卡信息
foreach($nets as $net){
	$netm = $net['net']['model'];
	$netr = getRealSizes($net['net']['receive']);
	$nett = getRealSizes($net['net']['transmit']);
	echo $netm,' 已接收 : ',$netr,' 已发送 : ',$nett;
	echo "<br />\n";
}
echo "<br />\n";
echo "TCP连接状态 : \n";
system('netstat -anl | awk \'/^tcp/ {++S[$NF]} END {for(a in S) print a, S[a]}\'');
echo "<br />\n";
echo "IP连接统计 : \n";
system('netstat -anltu | awk \'{print $5}\' | egrep -o "[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}" | sort | uniq -c | sort -nr');
echo "<br /><br />\n";
echo '</pre>';
?>

<script type="text/javascript"> 
<!--
$(document).ready(function(){getJSONData();});
function getJSONData()
{
	setTimeout("getJSONData()", 1000);
	$.getJSON('?act=rt&callback=?', displayData);
}
function displayData(dataJSON)
{
	$("#title").html(dataJSON.title);
	$("#freeSpace").html(dataJSON.freeSpace);
	$("#TotalMemory").html(dataJSON.TotalMemory);
	$("#UsedMemory").html(dataJSON.UsedMemory);
	$("#FreeMemory").html(dataJSON.FreeMemory);
	$("#CachedMemory").html(dataJSON.CachedMemory);
	$("#TotalSwap").html(dataJSON.TotalSwap);
	$("#UsedSwap").html(dataJSON.UsedSwap);
	$("#FreeSwap").html(dataJSON.FreeSwap);
	$("#loadAvg").html(dataJSON.loadAvg);
	$("#uptime").html(dataJSON.uptime);
	$("#freetime").html(dataJSON.freetime);
	$("#stime").html(dataJSON.stime);
	$("#bjtime").html(dataJSON.bjtime);
}
-->
</script>
</body>
</html>
<?php
function sys_linux()
{
	// UPTIME
	if (false === ($str = @file("/proc/uptime"))) return false;
	$str = explode(" ", implode("", $str));
	$str = trim($str[0]);
	$sec = $str;
	$min = $str / 60;
	$hours = $min / 60;
	$days = floor($hours / 24);
	$hours = floor($hours - ($days * 24));
	$min = floor($min - ($days * 60 * 24) - ($hours * 60));
	if ($days !== 0) $res['uptime'] = $days." Day ";
	if ($hours !== 0) $res['uptime'] .= $hours." Hour ";
	if ($min !== 0) $res['uptime'] .= $min." Min ";
	if ($sec < 60) $res['uptime'] .= $sec." Sec ";
	// FREETIME
	if (false === ($str = @file("/proc/uptime"))) return false;
	$str = explode(" ", implode("", $str));
	$str = trim($str[1]);
	$sec = $str;
	$min = $str / 60;
	$hours = $min / 60;
	$days = floor($hours / 24);
	$hours = floor($hours - ($days * 24));
	$min = floor($min - ($days * 60 * 24) - ($hours * 60));
	if ($days !== 0) $res['freetime'] = $days." Day ";
	if ($hours !== 0) $res['freetime'] .= $hours." Hour ";
	if ($min !== 0) $res['freetime'] .= $min." Min ";
	if ($sec < 60) $res['freetime'] .= $sec." Sec ";
	// MEMORY
	if (false === ($str = @file("/proc/meminfo"))) return false;
	$str = implode("", $str);
	preg_match_all("/MemTotal\s{0,}\:+\s{0,}([\d\.]+).+?MemFree\s{0,}\:+\s{0,}([\d\.]+).+?Cached\s{0,}\:+\s{0,}([\d\.]+).+?SwapTotal\s{0,}\:+\s{0,}([\d\.]+).+?SwapFree\s{0,}\:+\s{0,}([\d\.]+)/s", $str, $buf);
	$res['memTotal'] = getRealSize($buf[1][0]);
	$res['memFree'] = getRealSize($buf[2][0]);
	$res['memCached'] = getRealSize($buf[3][0]);
	$res['memUsed'] = getRealSize($res['memTotal']-$res['memFree']);
	$res['memPercent'] = (floatval($res['memTotal'])!=0)?round($res['memUsed']/$res['memTotal']*100,2):0;
	$res['memRealUsed'] = getRealSize($res['memTotal'] - $res['memFree'] - $res['memCached']);
	$res['memRealPercent'] = (floatval($res['memTotal'])!=0)?round($res['memRealUsed']/$res['memTotal']*100,2):0;
	$res['swapTotal'] = getRealSize($buf[4][0]);
	$res['swapFree'] = getRealSize($buf[5][0]);
	$res['swapUsed'] = getRealSize($res['swapTotal']-$res['swapFree']);
	$res['swapPercent'] = (floatval($res['swapTotal'])!=0)?round($res['swapUsed']/$res['swapTotal']*100,2):0;
	// LOAD AVG
	if (false === ($str = @file("/proc/loadavg"))) return false;
	$str = explode(" ", implode("", $str));
	$str = array_chunk($str, 4);
	$res['loadAvg'] = implode(" ", $str[0]);
	return $res;
}

//网卡信息读取
function net_dev()
{
	if (false === ($str = @file("/proc/net/dev"))) return false;
	$ress['net']['num'] = sizeof($str);
	for($i=2;$i<$ress['net']['num'];$i++){
		@preg_match_all( "/([^\s]+):[\s]{0,}(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)/", $str[$i], $info );
		$ress[$i-2]['net']['model'] = $info[1][0];
		$ress[$i-2]['net']['receive'] = $info[2][0];
		$ress[$i-2]['net']['transmit'] = $info[10][0];
	}
	return $ress;
}


//字节单位换算
function getRealSize($size)
{
	$mb = 1024;
	$gb = 1024 * $mb;
	$tb = 1024 * $gb;
	if($size < $mb)
	{
		return $size." KB";
	}
	else if($size < $gb)
	{
		return round($size/$mb,2)." MB";
	}
	else if($size < $tb)
	{
		return round($size/$gb,2)." GB";
	}
	else
	{
		return round($size/$tb,2)." TB";
	}
}
function getRealSizes($size)
{
	$kb = 1024;
	$mb = 1024 * $kb;
	$gb = 1024 * $mb;
	$tb = 1024 * $gb;
	if($size < $kb)
	{
		return $size." Bytes";
	}
	else if($size < $mb)
	{
		return round($size/$kb,2)." KB";
	}
	else if($size < $gb)
	{
		return round($size/$mb,2)." MB";
	}
	else if($size < $tb)
	{
		return round($size/$gb,2)." GB";
	}
	else
	{
		return round($size/$tb,2)." TB";
	}
}
?>