<?php
header("content-Type: text/html; charset=utf-8");
header("Cache-Control: no-cache, must-revalidate");
header("Pragma: no-cache");
error_reporting(E_ERROR | E_WARNING | E_PARSE);
ob_start();

//认证 KEY
$zKey = "test";
//是否检测MySQL,0为不检测,1为检测
$zSQL = "0";
//MySQL信息
$zServerName = "localhost";//MySQL服务器地址
$zUserName = "root";//MySQL用户名
$zPassWord = "123";//MySQL密码


if ($zSQL == "1"){
	//MySQL链接
	$zConn = mysql_connect($zServerName, $zUserName, $zPassWord);
	if($zConn){$zSQL_Status = "连接成功";}else{$zSQL_Status = "连接失败";}
	mysql_close($zConn);
}
//服务器信息
$zSysInfo = zSys();
//服务器IP
$zIP = $_SERVER["SERVER_ADDR"];
$zCIP = $_GET['ip'];
//服务器时间
$zSysTime = date("Y-n-j H:i:s");
//北京时间
$BJTime = gmdate("Y-n-j H:i:s",time()+8*3600);
//服务器在线时间
$zUpTime = $zSysInfo['uptime'];
//服务器空闲时间
$zFreeTime = $zSysInfo['freetime'];
//服务器磁盘信息
if ((@disk_total_space(".") !== null)&&(@disk_total_space(".") != 0)){
	$zSpace = "1";
	$df = zFS(round(@disk_free_space("."),4));
	$dt = zFS(round(@disk_total_space("."),4));
	$dr = round((@disk_free_space(".")/@disk_total_space("."))*100,4);
}else{$zSpace = "0";}
//服务器物理内存信息
if (($zSysInfo['memTotal'] !== null)&&($zSysInfo['memTotal'] != 0)){
	$zMem = "1";
	$mt = zFSS($zSysInfo['memTotal']);
	$mu = zFSS($zSysInfo['memUsed']);
	$mf = zFSS($zSysInfo['memFree']);
	$mc = zFSS($zSysInfo['memCached']);
	$mr = round(($zSysInfo['memUsed']/$zSysInfo['memTotal'])*100,4);
}else{$zMem = "0";}
//服务器SWAP内存信息
if (($zSysInfo['swapTotal'] !== null)&&($zSysInfo['swapTotal'] != 0)){
	$zSwap = "1";
	$st = zFSS($zSysInfo['swapTotal']);
	$su = zFSS($zSysInfo['swapUsed']);
	$sf = zFSS($zSysInfo['swapFree']);
	$sr = round(($zSysInfo['swapUsed']/$zSysInfo['swapTotal'])*100,4);
}else{$zSwap = "0";}
//服务器负载信息
/*
if ($zSysInfo['LoadAvg'] !== null){
	$zLoad = "1";
	$zLoad_1 = $zSysInfo['LoadAvg_1'];
	$zLoad_5 = $zSysInfo['LoadAvg_5'];
	$zLoad_15 = $zSysInfo['LoadAvg_15'];
	$zLoad_p = $zSysInfo['LoadAvg_p'];
}else{$zLoad = "0";}
*/
if (empty($zSysInfo['LoadAvg'])){$zLoad = "0";}else{
	$zLoad = "1";
	$zLoad_1 = $zSysInfo['LoadAvg_1'];
	$zLoad_5 = $zSysInfo['LoadAvg_5'];
	$zLoad_15 = $zSysInfo['LoadAvg_15'];
	$zLoad_p = $zSysInfo['LoadAvg_p'];
}




$zServ = $_GET['num']+1;
$zKey = md5($zKey);
$zKey = md5(getenv("SERVER_PROTOCOL")."+".$zCIP."+".$_SERVER["SERVER_PORT"]."+".getenv("REQUEST_METHOD")."+".$zKey);

if ($_GET['key'] == "key"){echo $zKey;exit;}
if ($_GET['act'] == $zKey)
{
$zArr = Array(
	'num' => "$zServ",
	'key' => "$zKey",
	'ServerIP' => "$zIP",
	'ServerloadAvg' => Array ( "$zLoad_1","$zLoad_5","$zLoad_15","$zLoad_p","$zLoad" ),
	'ServerSpace' => Array ( 'Space' => "$zSpace",'FreeSpace' => "$df",'TotalSpace' => "$dt",'RateSpace' => "$dr" ),
	'ServerMemory' => Array ( 'Mem' => "$zMem",'TotalMemory' => "$mt",'FreeMemory' => "$mf",'UsedMemory' => "$mu",'CachedMemory' => "$mc",'RateMemory' => "$mr" ),
	'ServerSwap' => Array ( 'Swap' => "$zSwap",'TotalSwap' => "$st",'FreeSwap' => "$sf",'UsedSwap' => "$su",'RateSwap' => "$sr" ),
	'ServerTime' => Array ( 'UpTime' => "$zUpTime",'FreeTime' => "$zFreeTime",'BJTime' => "$BJTime",'SysTime' => "$zSysTime" ),
	'ServerMysql' => Array ( 'SQL' => "$zSQL",'SQLStatus' => "$zSQL_Status" ),
);
$zJarr=json_encode($zArr); 
echo $_GET['callback'],'(',$zJarr,')';
exit;
}

function zSys()
{
	// UPTIME
	if (false === ($zStr = @file("/proc/uptime"))) return false;
	$zStr = explode(" ", implode("", $zStr));
	$zStr = trim($zStr[0]);
	$sec = $zStr;
	$min = $zStr / 60;
	$hours = $min / 60;
	$days = floor($hours / 24);
	$hours = floor($hours - ($days * 24));
	$min = floor($min - ($days * 60 * 24) - ($hours * 60));
	if ($days !== 0) $zRes['uptime'] = $days." Day ";
	if ($hours !== 0) $zRes['uptime'] .= $hours." Hour ";
	if ($min !== 0) $zRes['uptime'] .= $min." Min ";
	if ($sec < 60) $zRes['uptime'] .= $sec." Sec ";
	// FREETIME
	if (false === ($zStr = @file("/proc/uptime"))) return false;
	$zStr = explode(" ", implode("", $zStr));
	$zStr = trim($zStr[1]);
	$sec = $zStr;
	$min = $zStr / 60;
	$hours = $min / 60;
	$days = floor($hours / 24);
	$hours = floor($hours - ($days * 24));
	$min = floor($min - ($days * 60 * 24) - ($hours * 60));
	if ($days !== 0) $zRes['freetime'] = $days." Day ";
	if ($hours !== 0) $zRes['freetime'] .= $hours." Hour ";
	if ($min !== 0) $zRes['freetime'] .= $min." Min ";
	if ($sec < 60) $zRes['freetime'] .= $sec." Sec ";

	// MEMORY
	if (false === ($zStr = @file("/proc/meminfo"))) return false;
	$zStr = implode("", $zStr);
	preg_match_all("/MemTotal\s{0,}\:+\s{0,}([\d\.]+).+?MemFree\s{0,}\:+\s{0,}([\d\.]+).+?Cached\s{0,}\:+\s{0,}([\d\.]+).+?SwapTotal\s{0,}\:+\s{0,}([\d\.]+).+?SwapFree\s{0,}\:+\s{0,}([\d\.]+)/s", $zStr, $zBuf);
	$zRes['memTotal'] = $zBuf[1][0];
	$zRes['memFree'] = $zBuf[2][0];
	$zRes['memCached'] = $zBuf[3][0];
	$zRes['memUsed'] = $zRes['memTotal']-$zRes['memFree'];
	$zRes['memPercent'] = (floatval($zRes['memTotal'])!=0)?round($zRes['memUsed']/$zRes['memTotal']*100,2):0;
	$zRes['memRealUsed'] = $zRes['memTotal'] - $zRes['memFree'] - $zRes['memCached'];
	$zRes['memRealPercent'] = (floatval($zRes['memTotal'])!=0)?round($zRes['memRealUsed']/$zRes['memTotal']*100,2):0;
	$zRes['swapTotal'] = $zBuf[4][0];
	$zRes['swapFree'] = $zBuf[5][0];
	$zRes['swapUsed'] = $zRes['swapTotal']-$zRes['swapFree'];
	$zRes['swapPercent'] = (floatval($zRes['swapTotal'])!=0)?round($zRes['swapUsed']/$zRes['swapTotal']*100,2):0;

	//LOAD AVG
	if (false === ($zStr = @file("/proc/loadavg"))) return false;
	$zStr = explode(" ", implode("", $zStr));
	$zStr = array_chunk($zStr, 4);
	$zRes['LoadAvg'] = implode(" ", $zStr[0]);
	$zRes['LoadAvg_1'] = $zStr[0][0];
	$zRes['LoadAvg_5'] = $zStr[0][1];
	$zRes['LoadAvg_15'] = $zStr[0][2];
	$zRes['LoadAvg_p'] = $zStr[0][3];
	return $zRes;
}

function zFS($fileSize)
{
	$unit = array(' Bytes', ' KB', ' MB', ' GB', ' TB', ' PB', ' EB', ' ZB', ' YB');
	$i = 0;
	//由于计算机做乘法比做除法快
	$inv = 1 / 1024;
	while($fileSize >= 1024 && $i < 8)
	{
		$fileSize *= $inv;
		++$i;
	}
	$fileSizeTmp = sprintf("%.2f", $fileSize);
	//以下代码在99.99%的情况下结果会是正确的，除非你使用了"超超大数"。：）
	return ($fileSizeTmp - (int)$fileSizeTmp ? $fileSizeTmp : $fileSize) . $unit[$i];
}
function zFSS($fileSize)
{
	$unit = array(' KB', ' MB', ' GB', ' TB', ' PB', ' EB', ' ZB', ' YB');
	$i = 0;
	//由于计算机做乘法比做除法快
	$inv = 1 / 1024;
	while($fileSize >= 1024 && $i < 8)
	{
		$fileSize *= $inv;
		++$i;
	}
	$fileSizeTmp = sprintf("%.2f", $fileSize);
	//以下代码在99.99%的情况下结果会是正确的，除非你使用了"超超大数"。：）
	return ($fileSizeTmp - (int)$fileSizeTmp ? $fileSizeTmp : $fileSize) . $unit[$i];
}
?>